package com.sre.teaching.kafka.streams.bankapp.banktransactions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankTransactionsApplicationTests {

	@Test
	void contextLoads() {
	}

}

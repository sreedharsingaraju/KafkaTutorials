package com.sre.teaching.kafka.streams.streamingconsumerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StreamingConsumerDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.sre.teaching.kafka.streams.understandingdsl;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnderstandingDslApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.sre.teaching.kafka.streams.ms.streamconsumer.msstreamingconsumerdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsstreamingconsumerdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

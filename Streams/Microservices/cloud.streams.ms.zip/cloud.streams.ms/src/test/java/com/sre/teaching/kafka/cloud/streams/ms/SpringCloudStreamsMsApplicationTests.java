package com.sre.teaching.kafka.cloud.streams.ms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCloudStreamsMsApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.sre.teaching.kafka.cloud.streams.ms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringCloudStreamsMsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringCloudStreamsMsApplication.class, args);
	}

}
